const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = 600;
canvas.height = 400;

let player = { x: 50, y: 350, w: 30, h: 30, color: "pink", dy: 0, jump: -8, gravity: 0.4, grounded: false };
let goal = { x: 520, y: 350, w: 40, h: 40, color: "gold" };
let platforms = [{ x: 0, y: 380, w: 600, h: 20, color: "#444" }, { x: 200, y: 300, w: 100, h: 10, color: "#555" }, { x: 400, y: 250, w: 100, h: 10, color: "#555" }];

// criar corações flutuando
let hearts = [];
for (let i = 0; i < 20; i++) {
    hearts.push({ x: Math.random()*600, y: Math.random()*400, size: 12+Math.random()*8, dy: 0.5+Math.random()*1 });
}

document.addEventListener("keydown", e => {
    if (e.code === "ArrowUp" && player.grounded) {
        player.dy = player.jump;
        player.grounded = false;
    }
});

function drawRect(obj) {
    ctx.fillStyle = obj.color;
    ctx.fillRect(obj.x, obj.y, obj.w, obj.h);
}

function drawPlayer() {
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, player.w, player.h);
    // desenhar rostinho
    ctx.fillStyle = "#000";
    ctx.beginPath();
    ctx.arc(player.x + 8, player.y + 10, 3, 0, Math.PI*2); // olho esquerdo
    ctx.arc(player.x + 22, player.y + 10, 3, 0, Math.PI*2); // olho direito
    ctx.fill();
    ctx.beginPath();
    ctx.arc(player.x + 15, player.y + 20, 6, 0, Math.PI); // boca sorrindo
    ctx.stroke();
}

function drawHearts() {
    for (let h of hearts) {
        ctx.font = h.size + "px Arial";
        ctx.fillText("💖", h.x, h.y);
        h.y -= h.dy;
        if (h.y < -20) h.y = 400;
    }
}

function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // corações de fundo
    drawHearts();

    // Player physics
    player.y += player.dy;
    player.dy += player.gravity;
    player.grounded = false;

    // Collisions
    for (let p of platforms) {
        if (player.x < p.x + p.w && player.x + player.w > p.x &&
            player.y < p.y + p.h && player.y + player.h > p.y) {
            player.y = p.y - player.h;
            player.dy = 0;
            player.grounded = true;
        }
        drawRect(p);
    }

    // Goal check
    if (player.x < goal.x + goal.w && player.x + player.w > goal.x &&
        player.y < goal.y + goal.h && player.y + player.h > goal.y) {
        document.getElementById("endMessage").classList.remove("hidden");
        return;
    }

    // Draw player and goal
    drawPlayer();
    drawRect(goal);

    requestAnimationFrame(gameLoop);
}

gameLoop();